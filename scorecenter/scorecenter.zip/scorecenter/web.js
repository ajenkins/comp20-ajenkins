var express = require('express');

var app = express();
app.use(express.bodyParser());

var mongo = require('mongodb');

var mongoUri = process.env.MONGOLAB_URI ||
    process.env.MONGOHQ_URL ||
    'mongodb://localhost/scorecenter?safe=false';

var all_scores;
var cursor_all;
var collection;

mongo.Db.connect(mongoUri, function (error, databaseConnection) {
    if (error) { return console.dir(error); }
    else {
        console.log('Connected to database at ' + mongoUri);
        
        var db = databaseConnection;
        collection = db.collection('highscores');
    }
});

app.all('/', function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With");
  next();
 });

// Shows all scores for all games
app.get('/', function(req, res, next) {
    res.set('Content-Type', 'text/html');
    collection.find().toArray(function(err, items) {
        res.send(JSON.stringify(items) +
        "<form action='/usersearch' method='get'> \
            <input type='submit' value='Search for Users' \> \
        </form> \
        ");
    });
});

// JSON data for highscores
app.get('/highscores.json', function(req, res, next) {
    function compare(a,b) {
        if (parseInt(a.score) < parseInt(b.score))
            return 1;
        if (parseInt(a.score) > parseInt(b.score))
            return -1;
        return 0;
    }
    if (req.query.hasOwnProperty('game_title')) {
        collection.find(req.query).toArray(function(err, items) {
            res.send(items.sort(compare).slice(0,10));
        });
    }
    else {
        res.send(400, 'Expecting game_title in request');
    }
});

app.post('/submit.json', function(req, res, next) {
    var obj = req.body;
    if (obj.hasOwnProperty('game_title') &&
        obj.hasOwnProperty('username') &&
        obj.hasOwnProperty('score')) {
            var d = new Date();
            obj.created_at = d.toString();
            collection.insert(obj);
            res.send(200, "Score Submitted!" +
                "<form action='/' method='get'> \
                    <input type='submit' value='View all scores' \> \
                </form> \
                    ");
    }
    else {
        res.send(400, 'Wrong fields in request. You submitted: ' +
                        JSON.stringify(obj));
    }
});

app.get('/usersearch', function(req, res, next) {
    res.set('Content-Type', 'text/html');
    res.send(" \
        <form name='usersearch' action='/usersearch' method='post'> \
            <p>Username: <input type='text' name='name'/></p> \
            <p><input type='submit' value='Search' /> \
        </form> \
    ");
});

app.post('/usersearch', function(req, res, next) {
    var search = req.body.name;
    var title = "<p>Highscores for " + search + ":</p>";
    var score_list = "";
    collection.find({username:search}).toArray(function(err, items){
        for (var i = 0; i < items.length; i++) {
            score_list += "<p>" + items[i].game_title + " = " + items[i].score + "</p>";
        }
        res.send(title + score_list);
    });
});

var port = process.env.PORT || 5000;
app.listen(port, function() {
  console.log("Listening on " + port);
});
